def selection_sort(words):
    n = len(words)
    for i in range(n):
        min_index = i
        for j in range(i + 1, n):
            if words[j] < words[min_index]:
                min_index = j
        words[i], words[min_index] = words[min_index], words[i]

def sort_text_alphabetically(text):
    words = text.split()
    selection_sort(words)
    return ' '.join(words)
input_text ="My is zubair? name"
sorted_text = sort_text_alphabetically(input_text)
print("Sorted words:", sorted_text)
