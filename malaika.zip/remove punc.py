def remove_punctuation(zubair_input):
    custom_punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
    result = []
    for char in zubair_input:
        if char not in custom_punctuations:
            result.append(char)
    return ''.join(result)

zubair_input = "I am Zubair! I am a student //of artificial ''intelligence? Let's ,learn more."
cleaned_input = remove_punctuation(zubair_input)
print("String without punctuation:", cleaned_input)
