def luhn_algorithm(card_number):
    digits = [int(digit) for digit in str(card_number)]
    for i in range(len(digits) - 2, -1, -2):
        doubled = digits[i] * 2
        if doubled > 9:
            doubled -= 9
        digits[i] = doubled
    total_sum = sum(digits)
    return total_sum % 10 == 0
card_number = input("Enter the card number: ")
if luhn_algorithm(card_number):
    print("Valid card number.")
else:
    print("Invalid card number.")
